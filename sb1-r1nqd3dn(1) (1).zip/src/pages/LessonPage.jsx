import { useParams, Navigate } from 'react-router-dom';
import { useMemo } from 'react';
import LessonContent from '../components/lesson/LessonContent';
import PracticeSection from '../components/lesson/PracticeSection';
import { useLessonProgress } from '../hooks/useLessonProgress';
import { getLessonById, getNextLesson } from '../data/lessons/index.js';

export default function LessonPage() {
  const { id } = useParams();
  const { canAccessLesson, markLessonComplete } = useLessonProgress();

  const lesson = useMemo(() => getLessonById(parseInt(id)), [id]);
  const nextLesson = useMemo(() => getNextLesson(parseInt(id)), [id]);

  if (!lesson) {
    return <Navigate to="/lessons" replace />;
  }

  if (!canAccessLesson(lesson.id, lesson.difficulty)) {
    return <Navigate to="/lessons" replace />;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-teal-800 mb-6">{lesson.title}</h1>
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <LessonContent content={lesson.content} />
        
        {lesson.practice && (
          <PracticeSection 
            practice={lesson.practice}
            onComplete={() => markLessonComplete(lesson.id)}
          />
        )}
        
        {nextLesson && (
          <div className="mt-8 pt-4 border-t">
            <p className="text-gray-600 mb-2">Next up:</p>
            <h3 className="text-lg font-semibold text-teal-700">{nextLesson.title}</h3>
          </div>
        )}
      </div>
    </div>
  );
}