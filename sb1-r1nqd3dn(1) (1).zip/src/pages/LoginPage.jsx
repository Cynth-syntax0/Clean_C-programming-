import LoginForm from '../components/auth/LoginForm';

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-black via-purple-900 to-black">
      <div className="w-full max-w-md p-8 rounded-xl bg-gray-900/50 backdrop-blur-sm shadow-2xl">
        <h1 className="text-3xl font-bold text-white mb-8 text-center">Login</h1>
        <LoginForm />
      </div>
    </div>
  );
}