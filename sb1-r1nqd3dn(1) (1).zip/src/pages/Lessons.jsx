import { Link } from 'react-router-dom';
import { 
  beginnerLessons, 
  intermediateLessons, 
  expertLessons 
} from '../data/lessons/index.js';
import LessonCard from '../components/LessonCard';

export default function Lessons() {
  const lessonSections = [
    { title: 'Beginner Lessons', lessons: beginnerLessons },
    { title: 'Intermediate Lessons', lessons: intermediateLessons },
    { title: 'Expert Lessons', lessons: expertLessons }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-teal-800 mb-8">C Programming Lessons</h1>
      
      {lessonSections.map(section => (
        <div key={section.title} className="mb-12">
          <h2 className="text-2xl font-semibold text-teal-700 mb-6">{section.title}</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {section.lessons.map(lesson => (
              <LessonCard 
                key={lesson.id} 
                lesson={lesson}
              />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}