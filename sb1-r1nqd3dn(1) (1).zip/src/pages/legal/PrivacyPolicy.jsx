export default function PrivacyPolicy() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold text-teal-800 mb-8">Privacy Policy</h1>
      
      <div className="prose prose-teal">
        <p className="text-gray-600 mb-6">Last updated: January 2024</p>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-teal-700 mb-4">1. Information We Collect</h2>
          <p className="text-gray-600">We collect information you provide directly to us:</p>
          <ul className="list-disc pl-6 text-gray-600">
            <li>Account information (email, password)</li>
            <li>Profile information</li>
            <li>Learning progress and achievements</li>
            <li>Communications with us</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-teal-700 mb-4">2. How We Use Your Information</h2>
          <p className="text-gray-600">We use the information we collect to:</p>
          <ul className="list-disc pl-6 text-gray-600">
            <li>Provide and maintain our services</li>
            <li>Track your learning progress</li>
            <li>Send you important updates</li>
            <li>Improve our platform</li>
          </ul>
        </section>

        {/* Add more sections as needed */}
      </div>
    </div>
  );
}