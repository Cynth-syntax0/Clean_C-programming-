export default function About() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold text-teal-800 mb-8">About Clean_C</h1>
      
      <div className="prose prose-teal">
        <p className="text-xl text-gray-600 mb-6">
          Clean_C is a modern platform dedicated to teaching C programming through interactive lessons and practical exercises.
        </p>
        
        <h2 className="text-2xl font-semibold text-teal-700 mt-8 mb-4">Our Mission</h2>
        <p className="text-gray-600 mb-6">
          We aim to make learning C programming accessible, engaging, and effective for everyone, from beginners to advanced programmers.
        </p>
        
        <h2 className="text-2xl font-semibold text-teal-700 mt-8 mb-4">Our Approach</h2>
        <ul className="list-disc pl-6 text-gray-600 mb-6">
          <li>Interactive coding exercises</li>
          <li>Real-world examples</li>
          <li>Step-by-step guidance</li>
          <li>Immediate feedback</li>
        </ul>
      </div>
    </div>
  );
}