import { useState } from 'react';
import CodeEditor from '../components/CodeEditor';

const exercises = [
  {
    id: 1,
    title: "Print Numbers",
    difficulty: "Easy",
    description: "Write a program that prints numbers from 1 to 5.",
    initialCode: "#include <stdio.h>\n\nint main() {\n    // Your code here\n    return 0;\n}",
    solution: "#include <stdio.h>\n\nint main() {\n    for(int i = 1; i <= 5; i++) {\n        printf(\"%d\\n\", i);\n    }\n    return 0;\n}"
  },
  {
    id: 2,
    title: "Calculate Sum",
    difficulty: "Easy",
    description: "Write a program that calculates the sum of two numbers.",
    initialCode: "#include <stdio.h>\n\nint main() {\n    int a = 5, b = 3;\n    // Your code here\n    return 0;\n}",
    solution: "#include <stdio.h>\n\nint main() {\n    int a = 5, b = 3;\n    printf(\"Sum: %d\\n\", a + b);\n    return 0;\n}"
  }
];

export default function Exercises() {
  const [selectedExercise, setSelectedExercise] = useState(null);

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold text-teal-800 mb-8">Practice Exercises</h1>
      
      <div className="grid md:grid-cols-3 gap-8">
        <div className="col-span-1 space-y-4">
          <h2 className="text-xl font-semibold text-teal-700 mb-4">Exercise List</h2>
          {exercises.map(exercise => (
            <button
              key={exercise.id}
              onClick={() => setSelectedExercise(exercise)}
              className={`w-full p-4 rounded-lg text-left transition-all ${
                selectedExercise?.id === exercise.id
                  ? 'bg-teal-50 border-2 border-teal-600'
                  : 'bg-white border border-gray-200 hover:border-teal-600'
              }`}
            >
              <h3 className="font-semibold text-teal-800">{exercise.title}</h3>
              <p className="text-sm text-gray-600">Difficulty: {exercise.difficulty}</p>
            </button>
          ))}
        </div>
        
        <div className="col-span-2">
          {selectedExercise ? (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-teal-800 mb-2">{selectedExercise.title}</h2>
                <p className="text-gray-600 mb-4">{selectedExercise.description}</p>
              </div>
              
              <CodeEditor
                initialCode={selectedExercise.initialCode}
                solution={selectedExercise.solution}
                onComplete={() => console.log('Exercise completed!')}
              />
            </div>
          ) : (
            <div className="text-center text-gray-500 py-12">
              Select an exercise to begin
            </div>
          )}
        </div>
      </div>
    </div>
  );
}