// Mock authentication service
export const login = async ({ email, password }) => {
  // In a real app, this would make an API call
  if (email === 'admin@example.com' && password === 'admin123') {
    return { user: { id: 1, email }, role: 'admin' };
  }
  if (email === 'user@example.com' && password === 'user123') {
    return { user: { id: 2, email }, role: 'user' };
  }
  throw new Error('Invalid credentials');
};