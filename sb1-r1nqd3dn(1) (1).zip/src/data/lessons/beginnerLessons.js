export const beginnerLessons = [
  {
    id: 1,
    title: "Introduction to C Programming",
    difficulty: "beginner",
    content: `# Your First C Program

In this lesson, you'll learn the basics of C programming and write your first program.

## What You'll Learn
- Basic structure of a C program
- The main() function
- Printf function for output
- Comments in C

## Explanation
Every C program starts with a main() function. This is where your program begins executing.
The printf() function is used to display text on the screen.

### Program Structure
\`\`\`c
#include <stdio.h>  // Include standard input/output library

int main() {        // Main function - program starts here
    // Your code goes here
    return 0;       // End program
}
\`\`\`
`,
    practice: {
      task: `Write a program that prints "Hello, World!" to the console.

Requirements:
1. Use printf() function
2. Add a newline character (\\n) at the end
3. Return 0 from main()`,
      initialCode: `#include <stdio.h>

int main() {
    // Write your code here
    
}`,
      solution: `#include <stdio.h>

int main() {
    printf("Hello, World!\\n");
    return 0;
}`
    }
  },
  {
    id: 2,
    title: "Variables and Data Types",
    difficulty: "beginner",
    content: `# Understanding Variables and Data Types

## What You'll Learn
- Different data types in C
- How to declare variables
- How to initialize variables
- Printing variable values

## Data Types
1. int: Whole numbers (e.g., 42, -17)
2. float: Decimal numbers (e.g., 3.14)
3. char: Single characters (e.g., 'A', '7')

## Example
\`\`\`c
int age = 25;          // Integer
float height = 5.9;    // Float
char grade = 'A';      // Character
\`\`\`

## Printf Format Specifiers
- %d for integers
- %f for floats
- %c for characters
`,
    practice: {
      task: `Create a program that:
1. Declares an integer variable 'age' with value 20
2. Declares a float variable 'temperature' with value 98.6
3. Prints both values using proper format specifiers

Expected output:
Age: 20
Temperature: 98.6`,
      initialCode: `#include <stdio.h>

int main() {
    // Declare your variables here
    
    // Print the values
    
    return 0;
}`,
      solution: `#include <stdio.h>

int main() {
    int age = 20;
    float temperature = 98.6;
    
    printf("Age: %d\\n", age);
    printf("Temperature: %.1f\\n", temperature);
    return 0;
}`
    }
  }
];