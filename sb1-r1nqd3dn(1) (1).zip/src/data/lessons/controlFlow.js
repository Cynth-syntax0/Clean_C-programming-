export const controlFlow = [
  {
    id: 3,
    title: "Control Structures - If Statements",
    content: `Control structures allow you to make decisions in your programs.

Learn about:
• if statements
• if-else statements
• else if statements
• Nested if statements
• Comparison operators`,
    practice: {
      task: "Write a program that takes a number and prints whether it's positive, negative, or zero.",
      initialCode: "",
      solution: `#include <stdio.h>

int main() {
    int number = 5;
    
    if (number > 0) {
        printf("Positive\\n");
    } else if (number < 0) {
        printf("Negative\\n");
    } else {
        printf("Zero\\n");
    }
    return 0;
}`
    }
  },
  {
    id: 4,
    title: "Loops in C",
    content: `Loops are used to execute a block of code multiple times.

We'll cover:
• for loops
• while loops
• do-while loops
• Loop control statements (break, continue)
• Nested loops`,
    practice: {
      task: "Create a program that prints a multiplication table for the number 5 (from 1 to 10) using a for loop.",
      initialCode: "",
      solution: `#include <stdio.h>

int main() {
    int num = 5;
    
    for(int i = 1; i <= 10; i++) {
        printf("%d x %d = %d\\n", num, i, num * i);
    }
    return 0;
}`
    }
  }
];