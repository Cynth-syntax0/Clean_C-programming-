import { DIFFICULTY } from './types';

export function getLessonDifficulty(lesson) {
  return lesson.difficulty || DIFFICULTY.BEGINNER;
}

export function getLessonsByDifficulty(lessons, difficulty) {
  return lessons.filter(lesson => getLessonDifficulty(lesson) === difficulty);
}

export function validateLesson(lesson) {
  const requiredFields = ['id', 'title', 'content', 'difficulty'];
  return requiredFields.every(field => field in lesson);
}