export const expertLessons = [
  {
    id: 4,
    title: "Pointers and Memory Management",
    difficulty: "expert",
    content: `# Advanced Memory Management with Pointers

## What You'll Learn
- Understanding memory addresses
- Pointer declaration and initialization
- Dynamic memory allocation
- Memory leaks and prevention

## Pointer Basics
\`\`\`c
int number = 42;
int* ptr = &number;  // ptr stores address of number
*ptr = 100;         // Changes value of number to 100
\`\`\`

## Dynamic Memory
\`\`\`c
int* array = (int*)malloc(5 * sizeof(int));
// Use array
free(array);  // Always free allocated memory
\`\`\`
`,
    practice: {
      task: `Create a program that:
1. Dynamically allocates an array of 5 integers
2. Fills it with numbers 1 to 5
3. Prints the numbers using pointer arithmetic
4. Properly frees the memory

Expected output:
1 2 3 4 5`,
      initialCode: `#include <stdio.h>
#include <stdlib.h>

int main() {
    // Your code here
    
    return 0;
}`,
      solution: `#include <stdio.h>
#include <stdlib.h>

int main() {
    int* array = (int*)malloc(5 * sizeof(int));
    
    for(int i = 0; i < 5; i++) {
        array[i] = i + 1;
    }
    
    for(int i = 0; i < 5; i++) {
        printf("%d ", *(array + i));
    }
    printf("\\n");
    
    free(array);
    return 0;
}`
    }
  }
];