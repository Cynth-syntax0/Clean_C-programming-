export const basicConcepts = [
  {
    id: 1,
    title: "Getting Started with C",
    content: `Welcome to C programming! C is a powerful language that forms the foundation of many modern programming languages and operating systems.

Key points we'll cover:
• What is C programming?
• Why learn C?
• Basic structure of a C program
• Your first C program`,
    practice: {
      task: "Write your first C program that prints 'Hello, World!' to the console. Start from scratch!",
      initialCode: "",
      solution: `#include <stdio.h>

int main() {
    printf("Hello, World!\\n");
    return 0;
}`
    }
  },
  {
    id: 2,
    title: "Variables and Data Types",
    content: `Understanding variables and data types is crucial in C programming.

Key concepts:
• Integer types (int, short, long)
• Floating-point types (float, double)
• Character type (char)
• Variable declaration and initialization
• Constants`,
    practice: {
      task: "Create a program that declares variables of different types and prints their values. Include at least one integer, one float, and one character.",
      initialCode: "",
      solution: `#include <stdio.h>

int main() {
    int age = 25;
    float height = 5.9;
    char grade = 'A';
    
    printf("Age: %d\\n", age);
    printf("Height: %.1f\\n", height);
    printf("Grade: %c\\n", grade);
    return 0;
}`
    }
  }
];