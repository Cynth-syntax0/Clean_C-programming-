import { beginnerLessons } from './beginnerLessons';
import { intermediateLessons } from './intermediateLessons';
import { expertLessons } from './expertLessons';
import { DIFFICULTY } from './types';

// Combine all lessons
const allLessons = [
  ...beginnerLessons,
  ...intermediateLessons,
  ...expertLessons
];

// Helper functions
function getLessonById(id) {
  return allLessons.find(lesson => lesson.id === parseInt(id));
}

function getNextLesson(currentId) {
  const currentIndex = allLessons.findIndex(lesson => lesson.id === currentId);
  return allLessons[currentIndex + 1] || null;
}

// Export everything needed
export {
  DIFFICULTY,
  beginnerLessons,
  intermediateLessons,
  expertLessons,
  allLessons,
  getLessonById,
  getNextLesson
};