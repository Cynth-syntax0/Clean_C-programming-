export const intermediateLessons = [
  {
    id: 3,
    title: "Functions and Parameters",
    difficulty: "intermediate",
    content: `# Functions in C Programming

## What You'll Learn
- Function declaration and definition
- Parameters and return values
- Function prototypes
- Scope of variables

## Function Structure
\`\`\`c
returnType functionName(parameterType parameterName) {
    // Function body
    return value;
}
\`\`\`

## Example
\`\`\`c
int add(int a, int b) {
    return a + b;
}
\`\`\`
`,
    practice: {
      task: `Create a function called 'calculateArea' that:
1. Takes two parameters: length and width (both floats)
2. Calculates and returns the area (length * width)
3. In main(), call this function with values 5.0 and 3.0
4. Print the result

Expected output:
Area: 15.00`,
      initialCode: `#include <stdio.h>

// Write your function here

int main() {
    // Call your function here
    
    return 0;
}`,
      solution: `#include <stdio.h>

float calculateArea(float length, float width) {
    return length * width;
}

int main() {
    float area = calculateArea(5.0, 3.0);
    printf("Area: %.2f\\n", area);
    return 0;
}`
    }
  }
];