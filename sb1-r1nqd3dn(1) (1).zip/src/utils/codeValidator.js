export function validateCode(code, solution) {
  // Remove whitespace and newlines for comparison
  const normalizedCode = code.replace(/\s+/g, '');
  const normalizedSolution = solution.replace(/\s+/g, '');
  
  return normalizedCode === normalizedSolution;
}