import { memo } from 'react';
import CodeEditor from '../editor/CodeEditor';

function PracticeSection({ practice, onComplete }) {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-teal-700">Practice Exercise</h2>
      <div className="bg-gray-50 p-4 rounded-lg mb-4">
        <div className="whitespace-pre-line">{practice.task}</div>
      </div>
      <CodeEditor
        initialCode={practice.initialCode}
        solution={practice.solution}
        onComplete={onComplete}
      />
    </div>
  );
}

export default memo(PracticeSection);