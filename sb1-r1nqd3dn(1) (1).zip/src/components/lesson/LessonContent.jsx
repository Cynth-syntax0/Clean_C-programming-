import { memo } from 'react';

function LessonContent({ content }) {
  return (
    <div className="prose prose-teal max-w-none mb-8">
      <div className="whitespace-pre-line">{content}</div>
    </div>
  );
}

export default memo(LessonContent);