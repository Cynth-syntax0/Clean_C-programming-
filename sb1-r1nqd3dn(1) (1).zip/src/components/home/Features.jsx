import { motion } from 'framer-motion';
import AnimatedSection from './AnimatedSection';

const features = [
  {
    title: 'Interactive Learning',
    description: 'Practice with our built-in code editor and get instant feedback',
    icon: '💻'
  },
  {
    title: 'Step-by-Step Guide',
    description: 'Follow our carefully structured curriculum from basics to advanced',
    icon: '📚'
  },
  {
    title: 'Real-world Projects',
    description: 'Apply your knowledge with practical programming challenges',
    icon: '🚀'
  }
];

export default function Features() {
  return (
    <div className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <AnimatedSection className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Why Learn With Us?
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Master C programming with our comprehensive learning platform
          </p>
        </AnimatedSection>

        <div className="grid md:grid-cols-3 gap-12">
          {features.map((feature, index) => (
            <AnimatedSection key={feature.title}>
              <motion.div
                className="relative p-8 bg-gradient-to-br from-white to-teal-50 rounded-xl shadow-lg hover:shadow-xl transition-shadow"
                whileHover={{ y: -5 }}
                transition={{ duration: 0.2 }}
              >
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-teal-800 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </div>
  );
}