import { useState, useEffect } from 'react';
import { supabase } from '../../services/supabase';
import { toast } from 'react-toastify';

const challenges = [
  {
    id: 1,
    title: "Print Pattern",
    description: "Create a program that prints a triangle pattern using asterisks",
    difficulty: "Easy"
  },
  {
    id: 2,
    title: "Array Sum",
    description: "Calculate the sum of all elements in an array",
    difficulty: "Easy"
  },
  {
    id: 3,
    title: "Reverse String",
    description: "Write a program to reverse a string without using library functions",
    difficulty: "Easy"
  },
  // Add more challenges here...
];

export default function DailyChallenge() {
  const [timeLeft, setTimeLeft] = useState('');
  const [currentChallenge, setCurrentChallenge] = useState(null);
  const [hasAttempted, setHasAttempted] = useState(false);

  useEffect(() => {
    const checkAttemptStatus = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data } = await supabase
          .from('challenge_attempts')
          .select('*')
          .eq('user_id', user.id)
          .eq('date', new Date().toISOString().split('T')[0])
          .single();
        
        setHasAttempted(!!data);
      }
    };

    checkAttemptStatus();
  }, []);

  useEffect(() => {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);

    const updateTimer = () => {
      const now = new Date();
      const diff = tomorrow - now;
      
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);
      
      setTimeLeft(`${hours}h ${minutes}m ${seconds}s`);
    };

    // Set initial challenge
    const dayOfYear = Math.floor((now - new Date(now.getFullYear(), 0, 0)) / (1000 * 60 * 60 * 24));
    setCurrentChallenge(challenges[dayOfYear % challenges.length]);

    const timer = setInterval(updateTimer, 1000);
    updateTimer();

    return () => clearInterval(timer);
  }, []);

  const handleStartChallenge = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error('Please login to attempt the daily challenge');
      return;
    }

    if (hasAttempted) {
      toast.info('You have already attempted today\'s challenge');
      return;
    }

    // Record attempt
    await supabase
      .from('challenge_attempts')
      .insert([
        {
          user_id: user.id,
          challenge_id: currentChallenge.id,
          date: new Date().toISOString().split('T')[0]
        }
      ]);

    setHasAttempted(true);
    // Navigate to challenge page or open modal
  };

  if (!currentChallenge) return null;

  return (
    <div className="bg-gradient-to-br from-teal-50 to-green-50 py-12">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white p-8 rounded-xl shadow-lg">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-3xl font-bold text-teal-800">Daily Challenge</h2>
            <div className="text-gray-600">
              <span className="font-medium">Next challenge in: </span>
              <span className="font-mono">{timeLeft}</span>
            </div>
          </div>
          
          <div className="mb-6">
            <h3 className="text-xl font-semibold text-teal-700 mb-2">
              {currentChallenge.title}
            </h3>
            <p className="text-gray-600">{currentChallenge.description}</p>
            <div className="mt-2">
              <span className="inline-block px-3 py-1 rounded-full text-sm font-medium bg-teal-100 text-teal-800">
                {currentChallenge.difficulty}
              </span>
            </div>
          </div>

          <button
            onClick={handleStartChallenge}
            disabled={hasAttempted}
            className={`w-full py-3 px-6 rounded-lg font-semibold text-white 
              ${hasAttempted 
                ? 'bg-gray-400 cursor-not-allowed' 
                : 'bg-teal-600 hover:bg-teal-700 transition-colors'}`}
          >
            {hasAttempted ? 'Already Attempted' : 'Start Challenge'}
          </button>
        </div>
      </div>
    </div>
  );
}