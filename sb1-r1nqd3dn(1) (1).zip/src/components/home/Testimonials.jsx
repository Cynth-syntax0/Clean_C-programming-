export default function Testimonials() {
  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Computer Science Student',
      text: 'Clean_C made learning C programming enjoyable and straightforward.'
    },
    {
      name: 'Mike Chen',
      role: 'Software Developer',
      text: 'The interactive exercises helped me understand complex concepts easily.'
    }
  ];

  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-teal-800 mb-8">
          What Our Learners Say
        </h2>
        <div className="grid md:grid-cols-2 gap-8">
          {testimonials.map(testimonial => (
            <div key={testimonial.name} className="bg-white p-6 rounded-lg shadow-md">
              <p className="text-gray-600 mb-4">"{testimonial.text}"</p>
              <div>
                <p className="font-semibold text-teal-700">{testimonial.name}</p>
                <p className="text-sm text-gray-500">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}