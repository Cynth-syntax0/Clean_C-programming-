export default function Button({ children, type = 'button', onClick }) {
  return (
    <button
      type={type}
      onClick={onClick}
      className="w-full px-6 py-3 rounded-lg font-semibold text-white bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 focus:ring-2 focus:ring-purple-500 transition-all shadow-lg hover:shadow-purple-500/25"
    >
      {children}
    </button>
  );
}