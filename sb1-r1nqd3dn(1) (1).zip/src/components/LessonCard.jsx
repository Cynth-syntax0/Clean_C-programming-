import { Link } from 'react-router-dom';
import { useLessonProgress } from '../hooks/useLessonProgress';
import { LockIcon, CheckIcon } from './icons/Icons';

export default function LessonCard({ lesson }) {
  const { isLessonCompleted, canAccessLesson } = useLessonProgress();
  const isCompleted = isLessonCompleted(lesson.id);
  const isAccessible = canAccessLesson(lesson.id, lesson.difficulty);

  return (
    <div className={`bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow 
      ${!isAccessible ? 'opacity-75' : ''}`}>
      <div className="flex justify-between items-start mb-2">
        <h2 className="text-xl font-semibold text-teal-700">{lesson.title}</h2>
        {isCompleted && <CheckIcon className="w-6 h-6 text-green-500" />}
        {!isAccessible && <LockIcon className="w-6 h-6 text-gray-400" />}
      </div>
      
      <p className="text-gray-600 mb-4">
        {lesson.content.split('\n')[0].substring(0, 100)}...
      </p>

      {isAccessible ? (
        <Link
          to={`/lesson/${lesson.id}`}
          className="inline-block bg-teal-600 text-white px-4 py-2 rounded hover:bg-teal-700 transition-colors"
        >
          {isCompleted ? 'Review Lesson' : 'Start Lesson'}
        </Link>
      ) : (
        <div className="text-sm text-gray-500">
          Complete previous lessons to unlock
        </div>
      )}
    </div>
  );
}