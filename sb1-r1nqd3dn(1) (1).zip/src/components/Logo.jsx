export default function Logo() {
  return (
    <div className="flex items-center space-x-2">
      <span className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-purple-600 text-transparent bg-clip-text">
        {'{C}'}
      </span>
      <span className="font-semibold text-xl">Clean_C</span>
    </div>
  );
}