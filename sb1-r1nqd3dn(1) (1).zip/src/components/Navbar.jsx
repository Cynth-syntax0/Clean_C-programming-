import { Link } from 'react-router-dom';
import Logo from './Logo';

export default function Navbar() {
  const links = [
    { to: '/lessons', text: 'Lessons' },
    { to: '/exercises', text: 'Exercises' },
    { to: '/about', text: 'About' },
    { to: '/contact', text: 'Contact' },
  ];

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center">
            <Logo />
          </Link>
          <div className="flex space-x-8">
            {links.map(link => (
              <Link
                key={link.to}
                to={link.to}
                className="text-gray-600 hover:text-teal-600 transition-colors"
              >
                {link.text}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
}