import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import InputField from './InputField';
import Button from '../ui/Button';
import { login } from '../../services/authService';

export default function LoginForm() {
  const navigate = useNavigate();
  const [credentials, setCredentials] = useState({ email: '', password: '' });
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { user, role } = await login(credentials);
      const redirectPath = role === 'admin' ? '/admin' : '/dashboard';
      navigate(redirectPath);
    } catch (err) {
      setError('Invalid credentials. Please try again.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 w-full max-w-md">
      <InputField
        type="email"
        label="Email"
        value={credentials.email}
        onChange={(e) => setCredentials({ ...credentials, email: e.target.value })}
      />
      <InputField
        type="password"
        label="Password"
        value={credentials.password}
        onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
      />
      {error && <p className="text-red-500 font-semibold text-sm">{error}</p>}
      <Button type="submit">Login</Button>
      <div className="flex justify-between text-sm">
        <a href="/forgot-password" className="text-blue-400 hover:text-blue-300">
          Forgot Password?
        </a>
        <a href="/enable-2fa" className="text-blue-400 hover:text-blue-300">
          Enable 2FA
        </a>
      </div>
    </form>
  );
}