import Editor from '@monaco-editor/react';
import { useState, useEffect } from 'react';

export default function CodeEditor({ initialCode, solution, onComplete }) {
  const [code, setCode] = useState(initialCode);
  const [output, setOutput] = useState('');
  const [isCorrect, setIsCorrect] = useState(false);

  // Persist code in localStorage
  useEffect(() => {
    const savedCode = localStorage.getItem('currentCode');
    if (savedCode) {
      setCode(savedCode);
    }
  }, []);

  const handleCodeChange = (value) => {
    setCode(value);
    setIsCorrect(false);
    localStorage.setItem('currentCode', value);
  };

  const handleRunCode = () => {
    try {
      if (!code.trim()) {
        setOutput('❌ Code cannot be empty');
        return;
      }

      const normalizedCode = code.replace(/\s+/g, '');
      const normalizedSolution = solution.replace(/\s+/g, '');
      const correct = normalizedCode === normalizedSolution;
      
      if (correct) {
        setOutput('✅ Correct! Your code works as expected.');
        setIsCorrect(true);
        onComplete?.();
      } else {
        setOutput('❌ Not quite right. Try again!');
      }
    } catch (error) {
      setOutput(`❌ Error: ${error.message}`);
    }
  };

  return (
    <div className="space-y-4">
      <div className="border border-purple-500 rounded-lg overflow-hidden">
        <Editor
          height="400px"
          defaultLanguage="c"
          value={code}
          onChange={handleCodeChange}
          theme="vs-dark"
          options={{
            minimap: { enabled: false },
            fontSize: 16,
            lineNumbers: 'on',
            scrollBeyondLastLine: false,
            automaticLayout: true,
            tabSize: 2,
            fontFamily: "'Fira Code', monospace",
            fontLigatures: true,
            semanticHighlighting: true,
            bracketPairColorization: true,
            'semanticTokenColorCustomizations': {
              enabled: true,
              rules: {
                'variable': '#ff79c6',
                'function': '#50fa7b',
                'string': '#f1fa8c',
                'number': '#bd93f9',
                'keyword': '#ff79c6',
                'type': '#8be9fd',
                'comment': '#6272a4'
              }
            }
          }}
        />
      </div>
      
      <div className="flex space-x-4">
        <button
          onClick={handleRunCode}
          className="bg-purple-600 text-white px-6 py-2 rounded-md hover:bg-purple-700 transition-all duration-300 transform hover:scale-105"
        >
          Run Code
        </button>
        
        <button
          onClick={() => {
            setCode(initialCode);
            localStorage.setItem('currentCode', initialCode);
          }}
          className="border border-purple-600 text-purple-400 px-6 py-2 rounded-md hover:bg-purple-900/30 transition-all duration-300 transform hover:scale-105"
        >
          Reset Code
        </button>
      </div>

      {output && (
        <div className={`p-4 rounded-lg transition-all duration-300 ${
          isCorrect ? 'bg-green-900/20 text-green-400 border border-green-500' : 'bg-red-900/20 text-red-400 border border-red-500'
        }`}>
          {output}
        </div>
      )}
    </div>
  );
}