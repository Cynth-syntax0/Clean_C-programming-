import { memo } from 'react';

function EditorControls({ onRun, onReset }) {
  return (
    <div className="flex space-x-4">
      <button
        onClick={onRun}
        className="bg-teal-600 text-white px-6 py-2 rounded hover:bg-teal-700 transition-colors"
      >
        Run Code
      </button>
      
      <button
        onClick={onReset}
        className="border border-teal-600 text-teal-600 px-6 py-2 rounded hover:bg-teal-50 transition-colors"
      >
        Reset Code
      </button>
    </div>
  );
}

export default memo(EditorControls);