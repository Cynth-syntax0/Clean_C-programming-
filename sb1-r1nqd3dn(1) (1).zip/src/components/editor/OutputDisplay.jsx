import { memo } from 'react';

function OutputDisplay({ output, isCorrect }) {
  if (!output) return null;

  return (
    <div className={`p-4 rounded-lg ${isCorrect ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
      {output}
    </div>
  );
}

export default memo(OutputDisplay);