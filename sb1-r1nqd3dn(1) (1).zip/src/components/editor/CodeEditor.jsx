import { useState } from 'react';
import MonacoEditor from '@monaco-editor/react';
import EditorControls from './EditorControls';
import OutputDisplay from './OutputDisplay';

export default function CodeEditor({ initialCode, solution, onComplete }) {
  const [code, setCode] = useState(initialCode);
  const [output, setOutput] = useState('');
  const [isCorrect, setIsCorrect] = useState(false);

  const handleCodeChange = (value) => {
    setCode(value);
    setIsCorrect(false);
  };

  const handleRunCode = () => {
    try {
      if (!code.trim()) {
        setOutput('❌ Code cannot be empty');
        return;
      }

      const normalizedCode = code.replace(/\s+/g, '');
      const normalizedSolution = solution.replace(/\s+/g, '');
      const correct = normalizedCode === normalizedSolution;
      
      if (correct) {
        setOutput('✅ Correct! Your code works as expected.');
        setIsCorrect(true);
        onComplete?.();
      } else {
        setOutput('❌ Not quite right. Try again!');
      }
    } catch (error) {
      setOutput(`❌ Error: ${error.message}`);
    }
  };

  const handleReset = () => setCode(initialCode);

  return (
    <div className="space-y-4">
      <div className="border rounded-lg overflow-hidden">
        <MonacoEditor
          height="300px"
          defaultLanguage="c"
          value={code}
          onChange={handleCodeChange}
          theme="vs-dark"
          options={{
            minimap: { enabled: false },
            fontSize: 14,
            lineNumbers: 'on',
            scrollBeyondLastLine: false,
            automaticLayout: true,
            tabSize: 2
          }}
        />
      </div>
      
      <EditorControls onRun={handleRunCode} onReset={handleReset} />
      <OutputDisplay output={output} isCorrect={isCorrect} />
    </div>
  );
}