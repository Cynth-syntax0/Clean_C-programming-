import { useState } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

export default function CodePreview({ code }) {
  const [output, setOutput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const runCode = async () => {
    setIsLoading(true);
    try {
      // Simulate code execution
      const simulatedOutput = `Program output:\n${code}\n`;
      setOutput(simulatedOutput);
    } catch (error) {
      setOutput(`Error: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="mt-4 p-4 bg-gray-900 rounded-lg border border-purple-500">
      <div className="flex justify-between mb-2">
        <h3 className="font-semibold text-purple-300">Output</h3>
        <button
          onClick={runCode}
          disabled={isLoading}
          className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-all duration-300 disabled:opacity-50 transform hover:scale-105"
        >
          {isLoading ? 'Running...' : 'Run'}
        </button>
      </div>
      <div className="bg-gray-800 p-4 rounded-md border border-purple-400">
        <SyntaxHighlighter
          language="c"
          style={vscDarkPlus}
          customStyle={{
            margin: 0,
            background: 'transparent',
            padding: 0
          }}
        >
          {output || '// Click "Run" to see output'}
        </SyntaxHighlighter>
      </div>
    </div>
  );
}