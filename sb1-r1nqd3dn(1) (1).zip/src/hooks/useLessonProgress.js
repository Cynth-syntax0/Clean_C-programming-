import { useState, useEffect } from 'react';
import { DIFFICULTY } from '../data/lessons/types';

const PROGRESS_KEY = 'lesson_progress';

export function useLessonProgress() {
  const [completedLessons, setCompletedLessons] = useState(() => {
    try {
      const saved = localStorage.getItem(PROGRESS_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.error('Error loading progress:', error);
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(PROGRESS_KEY, JSON.stringify(completedLessons));
    } catch (error) {
      console.error('Error saving progress:', error);
    }
  }, [completedLessons]);

  const isLessonCompleted = (lessonId) => {
    return completedLessons.includes(lessonId);
  };

  const markLessonComplete = (lessonId) => {
    if (!completedLessons.includes(lessonId)) {
      setCompletedLessons([...completedLessons, lessonId]);
    }
  };

  const canAccessLesson = (lessonId, difficulty) => {
    if (difficulty === DIFFICULTY.BEGINNER) return true;
    
    const completedCount = completedLessons.length;
    
    switch (difficulty) {
      case DIFFICULTY.INTERMEDIATE:
        return completedCount >= 2;
      case DIFFICULTY.EXPERT:
        return completedCount >= 3;
      default:
        return false;
    }
  };

  return {
    isLessonCompleted,
    markLessonComplete,
    canAccessLesson,
    completedLessons
  };
}