import { useState } from 'react';

export function useLesson(initialCode, solution) {
  const [code, setCode] = useState(initialCode);

  const handleCodeChange = (value) => {
    setCode(value);
  };

  const handleRunCode = () => {
    // In a real implementation, this would:
    // 1. Compile and run the code
    // 2. Compare output with expected solution
    // 3. Return true if correct
    const isCorrect = code.trim() === solution.trim();
    return isCorrect;
  };

  return {
    code,
    handleCodeChange,
    handleRunCode
  };
}